import sys


if __name__ == "__main__":
    from .console import main

    sys.exit(main())
